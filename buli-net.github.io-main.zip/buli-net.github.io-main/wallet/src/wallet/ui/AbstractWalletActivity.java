/*
 * Copyright the original author or authors.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

package wallet.ui;

import android.app.ActivityManager.TaskDescription;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.MenuItem;
import androidx.fragment.app.FragmentActivity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import wallet.R;
import wallet.WalletApplication;
import wallet.util.Toast;

public abstract class AbstractWalletActivity extends FragmentActivity {
    private WalletApplication application;

    protected static final Logger log = LoggerFactory.getLogger(AbstractWalletActivity.class);

    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        application = (WalletApplication) getApplication();
        setTaskDescription(new TaskDescription(null, null, getColor(R.color.bg_action_bar)));
        super.onCreate(savedInstanceState);
    }

    public WalletApplication getWalletApplication() {
        return application;
    }

    @Override
    public boolean onOptionsItemSelected(final MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void startExternalDocument(final Uri url) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, url));
        } catch (final ActivityNotFoundException x) {
            log.info("Cannot view " + url, x);
            new Toast(this).longToast(R.string.toast_start_external_document_failed);
        } catch (final Exception x) {
            log.info("Cannot view " + url, x);
            new Toast(this).longToast(getString(R.string.toast_start_external_document_error, x.getClass().getName()));
        }
    }
}
