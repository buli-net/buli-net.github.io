/**
 * Copyright 2019 Anthony Trinh
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package ch.qos.logback.core.rolling;


import ch.qos.logback.core.LogbackException;

/**
 * A RolloverFailure occurs if, for whatever reason a rollover fails.
 *
 * @author Ceki Gulcu
 */
public class RolloverFailure extends LogbackException {

  private static final long serialVersionUID = -4407533730831239458L;

  public RolloverFailure(String msg) {
    super(msg);
  }

  public RolloverFailure(String message, Throwable cause) {
    super(message, cause);
  }
}
